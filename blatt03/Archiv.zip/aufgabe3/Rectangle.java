public class Rectangle extends Volume implements Comparable {

    public Rectangle(Point a, Point b) {
        super(a, b);
    }

    public int compareTo(Object o) {
        return super.compareTo(o);
    }
}