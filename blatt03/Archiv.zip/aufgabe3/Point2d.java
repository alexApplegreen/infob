public class Point2d extends Point implements Comparable {

    private double x, y;

    public Point2d(double x, double y) {
        super(x, y);
    }

    /**
     * @brief uses logic of class Point
     * @param o
     * @return
     */
    public int compareTo(Object o) {
        return super.compareTo(o);
    }
}